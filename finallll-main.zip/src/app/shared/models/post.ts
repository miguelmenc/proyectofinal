export class Post {
    title: string = "";
    description: string = "";
    text: string = "";
    image?: string= "";
    id?: string;
    }