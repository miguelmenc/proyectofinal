export class Games {
    uid?: string;
    nombre: string = "";
    descripcion?: string = '';
    desarolladora?: string = '';
    genero?: string = "";
    valoracion?: number = 0;
    UrlImgPortada?: string = "";
    UrlImgFondo?: string = "";
  }
  